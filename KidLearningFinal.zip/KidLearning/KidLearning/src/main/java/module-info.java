module com.example.kidlearning {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.kidlearning to javafx.fxml;
    exports com.example.kidlearning;
}